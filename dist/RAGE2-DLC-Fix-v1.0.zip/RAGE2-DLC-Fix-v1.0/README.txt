RAGE 2 - DLC fix for Bethesda.net being offline  (v1.0)

PROBLEM
RAGE 2 used to ask Bethesda.net which DLC you own. With the servers closed it never gets
an answer, so Rise of the Ghosts, Terrormania and the bonus content can't be triggered.

WHAT THIS DOES
Marks the DLC that already ships inside the game as owned, from within the game itself.
It does not touch Steam, Epic or any other launcher/store. FREE - please don't sell it.

INSTALL
1. Back up your saves.
2. Copy XINPUT9_1_0.dll next to RAGE2.exe and start the game.
3. rage2_dlcfix.ini and rage2_dlcfix.log appear in the same folder. In the ini:
     RiseOfTheGhosts=1   Rise of the Ghosts expansion
     Terrormania=1       Terrormania expansion
     OtherItems=1        other entitlement content (bonus mission, weapons, etc.)
   Set any of them to 0 to leave that part to the game.

UNINSTALL
Delete XINPUT9_1_0.dll from the game folder.

NOTES
- Built for the shipped RAGE2.exe v1.09; it checks the exe by byte signature and does
  nothing on a different build.
- If something is off, send rage2_dlcfix.log.
- Source: rage2_dlcfix.c (build line in the header).
